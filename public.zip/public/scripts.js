$(document).ready(function () {
  // By default, show the "inspectionForm1" and set "Deficiency Wise" button as active
  $("#deficiencyButton").addClass("btn-active");
  $("#inspectionForm1").show();
  $("#inspectionForm2").hide();

  // Handle click event for "Deficiency Wise" button
  $("#deficiencyButton").on("click", function () {
    $("#gearButton").removeClass("btn-active");
    $(this).addClass("btn-active");
    $("#inspectionForm1").show();
    $("#inspectionForm2").hide();
  });

  // Handle click event for "Gear Wise" button
  $("#gearButton").on("click", function () {
    $("#deficiencyButton").removeClass("btn-active");
    $(this).addClass("btn-active");
    $("#inspectionForm1").hide();
    $("#inspectionForm2").show();
  });
});

document.addEventListener('DOMContentLoaded', () => {

  const stationDropdown = document.getElementById('stationName');
  const gearDropdown = document.getElementById('gear');
  const zoneDropdown = document.getElementById('zone');

  // Event listener for changes in the "Station Name" dropdown
  stationDropdown.addEventListener('change', function () {
    const selectedStation = this.value;
    if (gearDropdown.value){
      const selectedGear = gearDropdown.value;
      const selectedZone = zoneDropdown.value;
      if (zoneDropdown.value){
        fetchGearIDs(selectedStation, selectedGear,selectedZone);
      }
      fetchZone(selectedStation, selectedGear);
      zoneDropdown.value= selectedZone;
 
     
    }
    else{
      fetchGears(selectedStation);
    }
  });

  // Event listener for changes in the "Gear" dropdown
  gearDropdown.addEventListener('change', function () {
    const selectedStation = stationDropdown.value;
    const selectedGear = this.value;
    const selectedZone = zoneDropdown.value;

    if (selectedZone.value){
      fetchGearIDs(selectedStation, selectedGear,selectedZone);
    }

    fetchZone(selectedStation, selectedGear);
    zoneDropdown.value= selectedZone;
    // Fetch gear IDs based on the selected station and gear
  
    
    // Fetch deficiencies based on the selected gear
    fetchDeficiencies(selectedGear);
  });

  zoneDropdown.addEventListener('change', function () {
    const selectedStation = stationDropdown.value;
    const selectedZone = this.value;
    const selectedGear = gearDropdown.value;

    // Fetch gear IDs based on the selected station and gear and zone 
    fetchGearIDs(selectedStation, selectedGear,selectedZone);

  });

  // Function to fetch gear options based on station name
  function fetchGears(stationName) {
    fetch(`/fetchGears/${stationName}`)
      .then(response => response.json())
      .then(data => {
        // Clear previous options
        gearDropdown.innerHTML = '<option value="" disabled selected>Select Gear</option>';
        data.forEach(gear => {
          const option = document.createElement('option');
          option.value = gear.Gear_type;
          option.textContent = gear.Gear_type;
          gearDropdown.appendChild(option);
        });
        const option = document.createElement('option');
        option.value = 'Point';
        option.textContent = 'Track Circuit';
        gearDropdown.appendChild(option);
      })
      .catch(error => console.error('Error:', error));
  }
    // Function to fetch gear options based on station name
    function fetchZone(stationName,gearName) {
      fetch(`/fetchZone/${stationName}/${gearName}`)
        .then(response => response.json())
        .then(data => {
          // Clear previous options
          zoneDropdown.innerHTML = '<option value="" disabled selected>Select Zone</option>';
          data.forEach(Zone => {
            const option = document.createElement('option');
            option.value = Zone.Zone;
            option.textContent = Zone.Zone;
            zoneDropdown.appendChild(option);
          });
        })
        .catch(error => console.error('Error:', error));
    }
  // Function to fetch gearID options based on station name and gear
  // function fetchGearIDs(stationName, gear) {

  //   for (let i = 3; i <= 12; i++) {
  //     const gearIDDropdown = document.getElementById(`gearID${i}`);
      
  //     fetch(`/fetchGearIDs/${stationName}/${gear}`)
  //       .then(response => response.json())
  //       .then(data => {
  //         // Clear previous options
  //         gearIDDropdown.innerHTML = '<option value="" disabled selected>Select Gear ID</option>';
  //         data.forEach(gearID => {
  //           const option = document.createElement('option');
  //           option.value = gearID.gear_ID;
  //           option.textContent = gearID.gear_ID;
  //           gearIDDropdown.appendChild(option);
  //         });
  //       })
  //       .catch(error => console.error('Error:', error));
  //   }
  // }

  // function fetchGearIDs(stationName, gear) {
  //   fetch(`/fetchGearIDs/${stationName}/${gear}`)
  //     .then(response => response.json())
  //     .then(data => {
  //       const gearIDArray = data.map(item => item.gear_ID);
        
  //       // Calculate loop endpoint based on gearIDArray length
  //       const loopEndpoint = Math.min(gearIDArray.length);
  //       fetchUpdatedLoopContent(loopEndpoint);
        
  //       for (let i = 3; i <= loopEndpoint; i++) {
  //         const gearIDField = document.getElementById(`gearID${i}`);
  //         gearIDField.value = gearIDArray[i - 3]; // Adjust index
  //       }
  //     })

  //     .catch(error => console.error('Error:', error));
  // }

  // function fetchUpdatedLoopContent(loopEndpoint) {
  //   $.ajax({
  //     url: `/getUpdatedLoop?loopEndpoint=${loopEndpoint}`,
  //     method: 'GET',
  //     success: function (data) {
  //       $('#dynamicFieldsContainer').html(data); // Replace the content of the placeholder element
  //     },
  //     error: function (error) {
  //       console.error('Error fetching updated loop content:', error);
  //     }
  //   });
  // }

  function fetchGearIDs(stationName, gear,Zone) {
    fetch(`/fetchGearIDs/${stationName}/${gear}/${Zone}`)
      .then(response => response.json())
      .then(data => {
        const gearIDArray = data.map(item => item.gear_ID);
        const loopEndpoint = Math.min(gearIDArray.length);
        document.getElementById("point_value").innerHTML = loopEndpoint;
        $(`#totalPoint`).css('visibility', 'visible');
  
        fetchUpdatedLoopContent(loopEndpoint)
          .then(() => {
            for (let i = 3; i <= loopEndpoint+2; i++) {
              const gearIDField = document.getElementById(`gearID${i}`);
              gearIDField.value = gearIDArray[i - 3];
              $(`#deficiencies${i}`).select2({
                closeOnSelect: false
              });
              fetchDeficiencies(gear,i)
              $(`#deficiencies${i}`).on('change', function() {
                showHideEntryFieldsForMultipleSets(i);
              });
            }

          })
          .catch(error => console.error('Error updating loop content:', error));
      })
      .catch(error => console.error('Error fetching gear IDs:', error));
  }
  
  function fetchUpdatedLoopContent(loopEndpoint) {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: `/getUpdatedLoop?loopEndpoint=${loopEndpoint}`,
        method: 'GET',
        success: function (data) {
          $('#dynamicFieldsContainer').html(data);
          resolve(); // Resolve the promise when content is updated
        },
        error: function (error) {
          console.error('Error fetching updated loop content:', error);
          reject(error); // Reject the promise in case of an error
        }
      });
    });
  }
  
  
  
  

  function fetchDeficiencies(gear,i) {
      fetch(`/fetchDeficiencies/${gear}`)
        .then(response => response.json())
        .then(data => {
          const deficienciesSelect = $(`#deficiencies${i}`);

          // Get the current selected options before updating
          const selectedOptions = deficienciesSelect.val() || [];

          // Assuming data is an array of options with { value, label } properties
          deficienciesSelect.empty();
          data.forEach(option => {
            const optionElement = new Option(option.list, option.list, false, false);
            deficienciesSelect.append(optionElement);
          });

          deficienciesSelect.trigger('change');

        })
        .catch(error => console.error('Error:', error));
    
  }


  function showHideEntryFieldsForMultipleSets(setIndex) {
    //  don't change the order for fileToHide  array
      var filedToHide = [
        'LOOSEPACKING',
        'LHSPOUR',
        'RHSPOUR',
        'CHAIRPLATED',
        'Guagewelding',
        'Guagebracket'
      ];
    
      var allConditions = [
        'stud bolt loose',
        'RH switch rail housing housing poor',
        //'L.H.S. housing poor',
        'R.H.S. housing poor',
        'Chair plated broken',
        'Guage tie plate bracket welding broken',
        'Guage tie plate bracket broken'
      ];
    
      for (var i = 0; i < filedToHide.length; i++) {
        $(`#${filedToHide[i]}${setIndex}`).css('visibility', 'hidden');
      }
      var selectedOptions = $(`#deficiencies${setIndex}`).val();
    
      for (var i = 0; i < allConditions.length; i++) {
        var selectedCondition = allConditions[i];
        var conditionID = filedToHide[i];
        switch (selectedCondition) {
          case 'stud bolt loose':
          case 'RH switch rail housing housing poor':
          //case 'L.H.S. housing poor':
          case 'R.H.S. housing poor':
          case 'Chair plated broken':
          case 'Guage tie plate bracket welding broken':
          case 'Guage tie plate bracket broken':
            if (selectedOptions.includes(selectedCondition)) {
              $(`#${conditionID}${setIndex}`).css('visibility', 'visible').prop('disabled', false);
            } else {
              $(`#${conditionID}${setIndex}`).css('visibility', 'hidden').prop('disabled', true);
              $(`#${conditionID}${setIndex} input`).val(''); // Clear input value
            }
            break;
          default:
            break;
        }
      }
    }
});



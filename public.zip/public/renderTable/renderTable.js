
let updateButtonData;

$(document).ready(function () {


    function populateUpdateForm(stationName, gear, gearID, date) {
        $('#station-name').val(stationName);
        $('#gear').val(gear);
        $('#gear-id').val(gearID);
        $('#date-of-deficiency').val(date);
        // Add logic to populate deficiency fields as needed
      }
    // Button to toggle the update form
    $('#data-table tbody').on('click', '.btn-edit', function () {
        const stationName = $(this).attr('data-station-attribute');
        const gear = $(this).attr('data-Gear-attribute');
        const gearID = $(this).attr('data-GearId-attribute');
        const date = $(this).attr('data-date-attribute');
        const deficiencies = $(this).attr('data-defi-attribute');
        const serialNumbers = $(this).attr('data-serial-attribute');
        updateButtonData = {
            deficiencies: deficiencies,
            srNo: serialNumbers
        };
        Deficiencies(gear,deficiencies)
        // $('#Deficiencies').select2({
        //     closeOnSelect: false
        //   });


        populateUpdateForm(stationName, gear, gearID, date);

    // Toggle the visibility of the update form
      $('#update-form').show();
         

     // Toggle the visibility of the form
    });

    function Deficiencies(gear,selectedOption) {
        fetch(`/fetchDeficiencies/${gear}`)
          .then(response => response.json())
          .then(data => {
            const deficienciesSelect = $('#Deficiencies');
            // Clear previous options
            deficienciesSelect.empty()
            const selectedOptionParts = selectedOption.split(',');
            const regex = /^\d+-/;
            const modifiedSelectedOptionParts = selectedOptionParts.map(item => item.replace(regex, ''));
            const modifiedSelectedOptionPart = modifiedSelectedOptionParts.map(item => item.replace(/^["/]+|["/]+$/g, ''));
            
            const modifiedSelectedOption = [...new Set(modifiedSelectedOptionPart)];
            console.log("modifiedSelectedOption");
            
            console.log(modifiedSelectedOption);
            
            data.forEach(option => {
                //const isSelected = modifiedSelectedOption.includes(option.list); // Check if this option should be pre-selected
                const optionElement = new Option(option.list, option.list, false, false);
                deficienciesSelect.append(optionElement);
            });
            deficienciesSelect.select2({
                closeOnSelect: false
              });
            
            modifiedSelectedOption.forEach(value => {
                deficienciesSelect.select2('trigger', 'select', { data: { id: value } });
              });
            deficienciesSelect.trigger('change');
          })
          .catch(error => console.error('Error:', error));
      }
  
    // Handle the "Submit Update" button click
    $('#submit-update').click(function () {
        const newDeficiency = $('#Deficiencies').val();
        console.log(typeof(newDeficiency));
        // Retrieve and update data from the form
        const updatedData = {
            stationName: $('#station-name').val(),
            gear: $('#gear').val(),
            gearID: $('#gear-id').val(),
            date: $('#date-of-deficiency').val(),
            deficiencies: $('#Deficiencies').val(),// Convert selected deficiencies to an array
            LHS:$('#LHS').val(),
            RHS:$('#RHS').val(),
            Loose:$('#Loose').val(),
            Chair:$('#Chair').val(),
            Guage:$('#Guage').val(),
            Guage_Tie:$('#Guage_Tie').val()
         };


    
        // Create empty arrays for updated and deleted deficiencies
        const updatedArray = [];
        const deletedArray = [];

        // Split selectedDeficiency and serialNumbers into arrays
        const selectedDeficiencie = updateButtonData.deficiencies.split(',');
        const selectedDeficiencies = selectedDeficiencie.map(item => item.replace(/^["/]+|["/]+$/g, ''));
        const serialNumberArray = updateButtonData.srNo.split(',');
        const serialNumbersArray = serialNumberArray.map(item => item.replace(/^["/]+|["/]+$/g, ''));
        //const newDeficiency = updatedData.deficiencies.split(',')


        newDeficiency.forEach(defi =>{
            if(!selectedDeficiencies.includes(defi)){
                updatedArray.push(defi)
            } 
        });

        selectedDeficiencies.forEach(defi =>{
            if(!newDeficiency.includes(defi)){
                const index = selectedDeficiencies.indexOf(defi);
                
                // If found, push the corresponding SR_NO to the deletedArray
                if (index !== -1 && serialNumbersArray.length > index) {
                    deletedArray.push(serialNumbersArray[index]);
                }
            } 
        });

// Now, updatedArray contains new deficiencies, and deletedArray contains SR_NO of deleted deficiencies


    
        // Now you have updatedArray and deletedArray with deficiencies and their respective serial numbers
        console.log('Updated Array:', updatedArray);
        console.log('Deleted Array:', deletedArray);
    
        // Add logic to send updated and deleted data to the backend as 
        
        
        const finalData = {
            updatedData: updatedData,
            updatedArray: updatedArray,
            deletedArray: deletedArray
        };
    
        // Send the data to your Node.js backend using AJAX
        $.ajax({
            type: 'POST', // Use 'POST' or 'PUT' based on your backend route
            url: '/performUpdate', // Replace with your actual backend route
            data: JSON.stringify(finalData),
            contentType: 'application/json',
            success: function (response) {
                // Handle the success response from the server
                console.log('Data successfully sent to the server:', response);
                location.reload();
            },
            error: function (error) {
                // Handle any errors that occur during the AJAX request
                console.error('Error sending data to the server:', error);
            }
        });

        $('#update-form').hide();

    });

    $(`#Deficiencies`).on('change', function() {
        showHideEntryFieldsForMultipleSets();
      });

    function showHideEntryFieldsForMultipleSets() {
        //  don't change the order for fileToHide  array
          var filedToHide = [
            'LOOSEPACKING',
            'LHSPOUR',
            'RHSPOUR',
            'CHAIRPLATED',
            'Guagewelding',
            'Guagebracket'
          ];
        
          var allConditions = [
            'Loose Packing',
            'L.H.S. housing poor',
            'R.H.S. housing poor',
            'Chair plated broken',
            'Guage tie plate bracket welding broken',
            'Guage tie plate bracket broken'
          ];
        
          for (var i = 0; i < filedToHide.length; i++) {
            $(`#${filedToHide[i]}`).css('visibility', 'hidden');
          }
          var selectedOptions = $(`#Deficiencies`).val();
        
          for (var i = 0; i < allConditions.length; i++) {
            var selectedCondition = allConditions[i];
            var conditionID = filedToHide[i];
            switch (selectedCondition) {
              case 'Loose Packing':
              case 'L.H.S. housing poor':
              case 'R.H.S. housing poor':
              case 'Chair plated broken':
              case 'Guage tie plate bracket welding broken':
              case 'Guage tie plate bracket broken':
                if (selectedOptions.includes(selectedCondition)) {
                  $(`#${conditionID}`).css('visibility', 'visible').prop('disabled', false);
                } else {
                  $(`#${conditionID}`).css('visibility', 'hidden').prop('disabled', true);
                  $(`#${conditionID} input`).val(''); // Clear input value
                }
                break;
              default:
                break;
            }
          }
        }
    
  });
  

  
  
  
  
  document.addEventListener('DOMContentLoaded', () => {
  
    const stationDropdown = document.getElementById('stationName');
    const gearDropdown = document.getElementById('gear');
    // Event listener for changes in the "Station Name" dropdown
    stationDropdown.addEventListener('change', function () {
      const selectedStation = this.value;
      fetchGears(selectedStation);
    });
  
    // Function to fetch gear options based on station name
    function fetchGears(stationName) {
      fetch(`/fetchGears/${stationName}`)
        .then(response => response.json())
        .then(data => {
          // Clear previous options
          gearDropdown.innerHTML = '<option value="" disabled selected>Select Gear</option>';
          data.forEach(gear => {
            const option = document.createElement('option');
            option.value = gear.Gear_type;
            option.textContent = gear.Gear_type;
            gearDropdown.appendChild(option);
          });
          const option = document.createElement('option');
          option.value = 'Point';
          option.textContent = 'Track Circuit';
          gearDropdown.appendChild(option);
        })
        .catch(error => console.error('Error:', error));
    }
      // Function to fetch gear options based on station name
  });
// working code ....
//   function createTable(data) {
//     const table = $('<table>');
//     const thead = $('<thead>');
//     const tbody = $('<tbody>');
  
//     const headerRow = $('<tr>');
//     headerRow.append($('<th>').text('DEFICIENCY'));
//     headerRow.append($('<th>').text('DLI DEVISION'));
  
//     // Get the unique SR_DEN values from the data
//     const srDenValues = new Set();
//     data.srDenResults.forEach(srDenItem => {
//       srDenValues.add(srDenItem);
//     });
  
//     // Add headers for SR_DEN values
//     srDenValues.forEach(srDenValue => {
//       headerRow.append($('<th>').text(srDenValue));
//     });
  
//     thead.append(headerRow);
  
//     data['Without SR_DEN'].forEach(item => {
//       const row = $('<tr>');
//       row.append($('<td>').text(item.DEFICIENCY));
//       row.append($('<td>').text(item.TOTAL_DEFICIENCY_COUNT));
  
//       srDenValues.forEach(srDenValue => {
//         const srDenData = data[srDenValue];
//         const deficiencyValue = item.DEFICIENCY;
  
//         if (srDenData && deficiencyValue) {
//           const matchingDeficiency = srDenData.find(
//             srDenItem => srDenItem.DEFICIENCY === deficiencyValue
//           );
  
//           if (matchingDeficiency) {
//             row.append($('<td>').text(matchingDeficiency.TOTAL_DEFICIENCY_COUNT || '0'));
//           } else {
//             row.append($('<td>').text('0'));
//           }
//         } else {
//           row.append($('<td>').text('0'));
//         }
//       });
  
//       tbody.append(row);
//     });
  
//     table.append(thead);
//     table.append(tbody);
  
//     // Display the table inside the #tableContainer
//     $('#tableContainer').html(table);
//   }
function createTable(data,stationName, gear) {
    const table = $('<table>');
    const thead = $('<thead>');
    const tbody = $('<tbody>');
  
    const headerRow = $('<tr>');
    headerRow.append($('<th>').text('DEFICIENCY'));
    headerRow.append($('<th>').text('DLI DIVISION'));
  
    // Get the unique SR_DEN values from the data
    const srDenValues = new Set();
    data.srDenResults.forEach(srDenItem => {
      srDenValues.add(srDenItem);
    });
  
    // Add headers for SR_DEN values
    srDenValues.forEach(srDenValue => {
      headerRow.append($('<th>').text(srDenValue));
    });
  
    thead.append(headerRow);
  
    data['Without SR_DEN'].forEach(item => {
      const row = $('<tr>');
  
      // Create a plain text cell for the DEFICIENCY column
      row.append($('<td>').text(item.DEFICIENCY));
  
      // Create a hyperlink for the TOTAL_DEFICIENCY_COUNT column
      const totalDeficiencyCountLink = $('<a>')
        .text(item.TOTAL_DEFICIENCY_COUNT)
        .attr('href', '#')
        .attr('data-stationName', stationName)
        .attr('data-gear', gear)
        .attr('data-columnName', 'DLI DIVISION')
        .attr('data-deficiencyName', item.DEFICIENCY)
        .addClass('custom-link');
  
      // Append the hyperlink to the <td>
      row.append($('<td>').append(totalDeficiencyCountLink));
  
      srDenValues.forEach(srDenValue => {
        const srDenData = data[srDenValue];
        const deficiencyValue = item.DEFICIENCY;
  
        if (srDenData && deficiencyValue) {
          const matchingDeficiency = srDenData.find(
            srDenItem => srDenItem.DEFICIENCY === deficiencyValue
          );
  
          if (matchingDeficiency) {
            // Create a hyperlink for other columns
            const otherLink = $('<a>')
              .text(matchingDeficiency.TOTAL_DEFICIENCY_COUNT || '0')
              .attr('href', '#')
              .attr('data-stationName', stationName)
              .attr('data-gear', gear)
              .attr('data-columnName', srDenValue)
              .attr('data-deficiencyName', deficiencyValue)
              .addClass('custom-link');
  
            // Append the hyperlink to the <td>
            row.append($('<td>').append(otherLink));
          } else {
            row.append($('<td>').text('0'));
          }
        } else {
          row.append($('<td>').text('0'));
        }
      });
  
      tbody.append(row);
    });
  
    table.append(thead);
    table.append(tbody);
  
    // Display the table inside the #tableContainer
    $('#tableContainer').html(table);
  
    // Add a click event handler for the hyperlinks
    $('a[data-columnName]').click(function (e) {
        e.preventDefault();
      
        const stationName = $(this).attr('data-stationName');
        const gear = $(this).attr('data-gear');
        const columnName = $(this).attr('data-columnName');
        const defValue = $(this).attr('data-deficiencyName');
      
        // Send the values to the backend using AJAX
        $.ajax({
          url: '/backend-endpoint',
          method: 'GET',
          data: {
            stationName: stationName,
            gear: gear,
            columnName: columnName,
            defi: defValue
          },
          dataType: 'json',
          success: function (response) {
            // Open a new window with an empty HTML page
            const newWindow = window.open('', '_blank');
      
            // Create a document in the new window
            const newWindowDoc = newWindow.document.open();
            newWindowDoc.write('<!DOCTYPE html><html><head><style>' +
              // Your CSS styles here
              '.custom-table { ' +
              'border-collapse: separate;' +
              'border-spacing: 0px 1px;' +
              'background-color: #e8eef5;' +
              'width: 100%;' +
              '}' +
              '.custom-table tbody tr {' +
              'border-bottom: 2px solid #b5d4fd;' +
              '}' +
              '.custom-table tbody tr:nth-child(odd) {' +
              'background-color: #ffffff;' +
              '}' +
              '.custom-table tbody tr:nth-child(even) {' +
              'background-color: #ffffff;' +
              '}' +
              '.custom-table thead:after {' +
              'display: block;' +
              'height: 0px;' +
              'content: "";' +
              'border: none;' +
              '}' +
              '.custom-table th {' +
              'background-color: #dce0e6;' +
              'text-align: center;' +
              'font-size: 18px;' +
              '}' +
              '.custom-table th, .custom-table td {' +
              'padding: 0.8em;' +
              'border-right: 3px solid white;' +
              '}' +
              '.custom-table th:last-child, .custom-table td:last-child {' +
              'border: none;' +
              '}' +
              '.custom-table td {' +
              'background-color: #eff4f6;' +
              'font-size: 16px;' +
              '}' +
              '.table-container {' +
              'max-height: 400px;' +
              'overflow: auto;' +
              '}' +
              '</style></head><body></body></html>');
            newWindowDoc.close();
      
            // Generate a new table in the new window's body
            const table = $('<table>');
            table.addClass('custom-table');
      
            // Create a header row with column headings
            const headerRow = $('<tr>');
            headerRow.append($('<th>').text('Station Code'));
            headerRow.append($('<th>').text('GEAR'));
            headerRow.append($('<th>').text('GEAR ID'));
            headerRow.append($('<th>').text('SR DEN'));
            headerRow.append($('<th>').text('Date of inspection'));
            headerRow.append($('<th>').text('DEFICIENCIES'));
            table.append(headerRow);
      
            // Build the table rows and cells from the response data
            $.each(response, function (index, item) {
              const row = $('<tr>');
              row.append($('<td>').text(item.STN_CODE));
              row.append($('<td>').text(item.GEAR));
              row.append($('<td>').text(item.GEAR_ID));
              row.append($('<td>').text(item.SR_DEN));
              row.append($('<td>').text(item.Date_of_inspection));
              row.append($('<td>').text(item.DEFICIENCIES));
              table.append(row);
            });
      
            // Append the table to the new window's body
            $(newWindow.document.body).append(table);
          },
          error: function (error) {
            console.error('Error sending data to the backend:', error);
          }
        });
      });
      
      
      
  }
  

    // Use jQuery to handle the form submission
    $('#submitButton').click(function (e) {
        e.preventDefault(); // Prevent the form from submitting in the traditional way
    
        // Get the selected values
        const stationName = $('#stationName').val();
        const gear = $('#gear').val();
    
        // Make an AJAX request to fetch data from the backend
        $.ajax({
          url: '/dashboard/data', // Replace with your actual API endpoint
          method: 'GET',
          data: { stationName: stationName, gear: gear },
          dataType: 'json',
          success: function (data) {
            console.log(data);
            // Call a function to create the table with the fetched data
            createTable(data,stationName, gear);
          },
          error: function (error) {
            console.error('Error fetching data:', error);
          }
        });
      });
    
    
  
  
  